#if [ "$#" -ne 1 ]; then
#    echo "Illegal number of parameters. Please provide the following:
#        1)Type of optimization (e.g. WriteEDP, ReadEDP)"
#    exit 1
#fi
#type=$1
#echo $type
for opt in ReadLatency WriteLatency ReadDynamicEnergy WriteDynamicEnergy Area ReadEDP WriteEDP Leakage
do
for cap in 1 2 4 8 16 32
do
for cacheAccess in Normal Fast Sequential
do
#for cell in cmos_sram_6t mtj_stt_1t1r mtj_sot_2t1r
for cell in mtj_stt_1t1r
do
 optType="-OptimizationTarget:"
 optType=$optType' '$opt
 newCommand="-Capacity (MB):"
 newCommand=$newCommand' '$cap
 cellType="-MemoryCellInputFile:"
 cellType=$cellType' '${cell}.cell
 cacheType='-CacheAccessMode:'
 cacheType=$cacheType' '$cacheAccess
 fileName=$cell'_'$cap"MB_"$opt'_'$cacheAccess".log"
 echo $fileName
 echo $newCommand
 echo $cellType
 sed -i "19s/.*/$optType/" nvsim.cfg
 sed -i "27s/.*/$newCommand/" nvsim.cfg
 sed -i "79s/.*/$cellType/" nvsim.cfg
 ./nvsim > sweepReports/$fileName
done
done
done
done
