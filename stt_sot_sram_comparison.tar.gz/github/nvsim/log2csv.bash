#!/bin/bash
if [ "$#" -ne 1 ]; then
    echo "Illegal number of parameters. Please provide the following:
        1)Opt Type"
    exit 1
fi
opt=$1
access=Sequential
for log in area readEnergy readLatency writeEnergy writeLatency
do
fileName=${log}_${opt}.log
python /afs/ece.cmu.edu/usr/misgenc/nvsim/NVSim-master/sweepReports/parser.py $fileName
done
