import sys
import csv
from itertools import izip
fileName=sys.argv[-1]

#change this parameter w.r.t to the cache size flavors
CAPACITY_FLAVORS=6
#bitcell types
BITCELL_FLAVORS=['SRAM','STT','SOT']

def parser(fileName):
 dataList=[]
 f=open(fileName,"r")
 for line in f:
  passFlag=False
  if("Area" in line):
   newline=line.split("=")[-1]
   if("mm^2" in line):
    newline=newline[:-5]
   else:
    newline=float(newline[:-5])/1000000
  elif("Latency" in line):
   newline=line.split('=')[-1]
   if("ns" in line):
    newline=newline[:-3]
   elif("ps" in line):
    newline=float(newline[:-3])/1000
   elif("us" in line):
    newline=float(newline[:-3])*1000
  elif("Energy" in line):
   newline=line.split('=')[-1]
   if("nJ" in line):
    newline=newline[:-14]
    #print(newline)
   else:
    newline=float(newline[:-14])/1000
  else:
   passFlag=True
  
  if(passFlag==False):
   dataList.append(newline)
 return dataList
 
dataList=parser(fileName)
sramList=dataList[0:CAPACITY_FLAVORS]
sttList=dataList[CAPACITY_FLAVORS:2*CAPACITY_FLAVORS]
sotList=dataList[2*CAPACITY_FLAVORS:3*CAPACITY_FLAVORS]

#print('data list!', dataList)
#print('sram list!', sramList)
#print('stt list!', sttList) 
#print('sot list!', sotList) 
csvName=fileName[:-4]+'.csv'
with open(csvName, 'wb') as f:
 writer = csv.writer(f)
 writer.writerows(izip(sramList, sttList, sotList))
  
 
