#!/bin/bash

for opt in ReadLatency WriteLatency ReadDynamicEnergy WriteDynamicEnergy Area ReadEDP WriteEDP
do
for access in Normal Fast Sequential
do
cd ${opt}_${access}_reports
echo $opt $access
python /afs/ece.cmu.edu/usr/misgenc/nvsim/NVSim-master/scripts/proxyCompare.py readLatency_${opt}.csv writeLatency_${opt}.csv
python /afs/ece.cmu.edu/usr/misgenc/nvsim/NVSim-master/scripts/proxyCompare.py readEnergy_${opt}.csv writeEnergy_${opt}.csv
cd ../.
done
done

