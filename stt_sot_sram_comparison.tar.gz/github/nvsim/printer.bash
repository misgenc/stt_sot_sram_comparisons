#!/bin/bash
#if [ "$#" -ne 2 ]; then
#    echo "Illegal number of parameters. Please provide the following:
#        1)Optimization Type
#        2)Cache Access Type"
#    exit 1
#fi
#optType=$1
#access=$2
for opt in ReadLatency WriteLatency ReadDynamicEnergy WriteDynamicEnergy Area ReadEDP WriteEDP
do
for access in Normal Fast Sequential
do
mkdir ${opt}_${access}_reports
for cell in cmos_sram_6t mtj_stt_1t1r mtj_sot_2t1r
do
echo $cell >> area_${opt}.log
echo $cell >> readLatency_${opt}.log
echo $cell >> writeLatency_${opt}.log
echo $cell >> readEnergy_${opt}.log
echo $cell >> writeEnergy_${opt}.log
for cap in 1 2 4 8 16 32
do
fileName=${cell}_${cap}MB_${opt}_${access}.log
echo "reading from " $fileName
if [ $cell == "cmos_sram_6t" ]; then
#Area
sed -n -e 25p $fileName >> area_${opt}.log
#Read Latency
sed -n -e 29p $fileName >> readLatency_${opt}.log
#Write Latency
sed -n -e 31p $fileName >> writeLatency_${opt}.log
#Read Energy
sed -n -e 33p $fileName >> readEnergy_${opt}.log
#Write Energy
sed -n -e 35p $fileName >> writeEnergy_${opt}.log
else
#Area
sed -n -e 33p $fileName >> area_${opt}.log
#Read Latency
sed -n -e 37p $fileName >> readLatency_${opt}.log
#Write Latency
sed -n -e 39p $fileName >> writeLatency_${opt}.log
#Read Energy
sed -n -e 41p $fileName >> readEnergy_${opt}.log
#Write Energy
sed -n -e 43p $fileName >> writeEnergy_${opt}.log
fi
done
done
mv *_${opt}.log ${opt}_${access}_reports
cd ${opt}_${access}_reports
../log2csv.bash ${opt}
cd ../.
done
done

